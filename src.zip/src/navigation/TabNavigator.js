// navigation/TabNavigator.js
import React, { useContext, useEffect } from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { View, Text, TouchableOpacity } from 'react-native';
import { AuthContext } from '../context/AuthContext';

const Tab = createBottomTabNavigator();

const DummyScreen = ({ title }) => (
  <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
    <Text>{title}</Text>
  </View>
);

// Proper Logout screen component
const LogoutScreen = () => {
  const { logout } = useContext(AuthContext);

  useEffect(() => {
    // when this screen mounts, clear the token
    logout();
  }, [logout]);

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Logging you out…</Text>
    </View>
  );
};

const TabNavigator = () => (
  <Tab.Navigator screenOptions={{ headerShown: false }}>
    <Tab.Screen
      name="Menu"
      children={() => <DummyScreen title="Menu Placeholder" />}
    />
    <Tab.Screen
      name="Settings"
      children={() => <DummyScreen title="Settings" />}
    />
    <Tab.Screen
      name="Dashboard"
      children={() => <DummyScreen title="Dashboard (JSON)" />}
    />
    <Tab.Screen
      name="Alerts"
      children={() => <DummyScreen title="Alerts" />}
    />
    <Tab.Screen
      name="Logout"
      component={LogoutScreen}  // ← use the standalone component
      options={{
        tabBarButton: (props) => (
          <TouchableOpacity {...props}>
            <Text>Logout</Text>
          </TouchableOpacity>
        ),
      }}
    />
  </Tab.Navigator>
);

export default TabNavigator;
