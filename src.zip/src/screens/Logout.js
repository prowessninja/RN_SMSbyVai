import React, { useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const Logout = ({ navigation }) => {
  useEffect(() => {
    const logout = async () => {
      await AsyncStorage.removeItem('userToken');
      navigation.reset({
        index: 0,
        routes: [{ name: 'Login' }],
      });
    };
    logout();
  }, []);

  return null;
};

export default Logout;
