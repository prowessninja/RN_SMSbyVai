// context/AuthContext.js
import React, { createContext, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [token, setToken] = useState(null);

  const restoreToken = async () => {
    const storedToken = await AsyncStorage.getItem('userToken');
    if (storedToken) setToken(storedToken);
  };

  const logout = async () => {
    await AsyncStorage.removeItem('userToken');
    setToken(null);
  };

  return (
    <AuthContext.Provider value={{ token, setToken, logout, restoreToken }}>
      {children}
    </AuthContext.Provider>
  );
};
